# E1 resource icons — Plate set (locked)

Direction 1b "Plate" with the 2a "Forged" bitcoin. Solid faceted silhouettes,
45° chamfers, 64×64 viewBox, one flat fill per file, no filters — built to hold
from 128 px art down to 16 px inline rules text.

## Files → repo destination

Drop `art/resources/*.svg` over the existing files (same names, same
role/title conventions), then regenerate PNGs with `scripts/rasterize-icons.cjs`.

## Locked affinity palette

| Resource | Hex | Was |
| --- | --- | --- |
| Power (energy) | #F3C244 yellow | #FF6A00 |
| Bitcoin | #F7931A orange | #F3C244 |
| Keys | #FFF7EC white | #7447B8 |
| Signal | #7447B8 violet | #FFF7EC |
| Timelock | #17BEBB cyan | #17BEBB |

Remap by RESOURCE, not by find-and-replace — the old bitcoin hex is the new
power hex, and keys/signal swapped. Keys is white: verify contrast wherever it
renders on light or orange surfaces.

See CODE-AGENT-PROMPT.md for the implementation prompt.
