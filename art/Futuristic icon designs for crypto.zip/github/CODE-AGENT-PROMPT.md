# Start prompt for the code agent

Paste everything below into the code agent at the TCG600nap repo root, with the
`github/` folder from this design project copied somewhere it can read.

---

Replace the five E1 resource icons with the new locked "Plate" set and roll the
new affinity palette through the build.

Source of truth: the five SVGs in `github/art/resources/` (power, bitcoin,
keys, signal, timelock). 64×64 viewBox, one solid fill each, no filters. Do not
redraw them.

Locked palette (remap by RESOURCE — a blind find-and-replace will corrupt
colors because old-bitcoin equals new-power, and keys/signal swapped):

- Power:    #FF6A00 → #F3C244 (yellow)
- Bitcoin:  #F3C244 → #F7931A (orange)
- Keys:     #7447B8 → #FFF7EC (white)
- Signal:   #FFF7EC → #7447B8 (violet)
- Timelock: #17BEBB → #17BEBB (unchanged)

Tasks:
1. Overwrite `art/resources/{power,bitcoin,keys,signal,timelock}.svg` with the
   new files, keeping the existing `role`/`<title>` conventions.
2. Regenerate rasterized icons: `scripts/rasterize-icons.cjs` →
   `art/resources/png/`.
3. Sweep for hardcoded affinity colors and remap per the table above. Check at
   least: `scripts/build_card_set.py`, `scripts/render_card_pngs.py`,
   `scripts/build_cards.py`, `scripts/build_promos.py`,
   `scripts/build_placeholders.py`, `site/fx.js`, `site/play.js`,
   `site/engine.js`, and inline CSS in `site/*.html`. Resource stripes on card
   frames follow the same mapping.
4. Rebuild card faces and proofs per the README: `build_cards.py`,
   `build_card_set.py`, `render_card_pngs.py` (web + print), `build_gallery.py`.
5. Visual QA: cost pips legible at 54 px on card faces and 16 px inline in
   rules text; white Keys must only sit on dark chips/surfaces — flag any spot
   it lands on orange or cream, and use a dark backing chip there.
6. Run the test suites (`uv run pytest`, `npm test`) and fix fallout from the
   palette change (e.g. snapshot or color-constant assertions).

Constraints: do not touch card text, art prompts, or locked artwork; keep every
icon single-color; no new dependencies.
